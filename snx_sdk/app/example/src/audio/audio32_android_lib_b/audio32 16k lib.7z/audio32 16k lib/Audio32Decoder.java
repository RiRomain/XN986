package com.android.AudioCodec;

public class Audio32Decoder {
	public native static String stringFromJNI();
	public native static void init(short sample_rate, short bit_rate, short in_size, short out_size);
	public native static short[] decode(short[] input);

	static { 
		try {
			System.loadLibrary("Audio32Decoder");
		}catch(UnsatisfiedLinkError ule) {
			System.out.println("loadLibrary(Audio32Decoder)," + ule.getMessage());
		}
	}
}
