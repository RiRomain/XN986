package com.android.AudioCodec;

public class Audio32Encoder {
	public native static String stringFromJNI();
	public native static void init(int sample_rate, int bit_rate, short in_size, short out_size);
	public native static short[] encode(short[] input);

	static { 
		try {
			System.loadLibrary("Audio32Encoder");
		}catch(UnsatisfiedLinkError ule) {
			System.out.println("loadLibrary(Audio32Encoder)," + ule.getMessage());
		}
	}
}
