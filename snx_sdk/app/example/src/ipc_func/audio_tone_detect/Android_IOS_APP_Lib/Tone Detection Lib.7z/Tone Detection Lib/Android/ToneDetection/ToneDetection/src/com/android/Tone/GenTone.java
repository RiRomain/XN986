package com.android.Tone;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.AsyncTask;

import com.example.tonedetectionv3.R;

public class GenTone {
	AudioTrack aTrack;
	Context ctx;

	private String dir = null;
	ToneAsync tA;
	Transfer trans = new Transfer();
	int index = 0;

	public GenTone(Context context) {
		// TODO Auto-generated constructor stub
		ctx = context;
		try {
			dir = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).applicationInfo.dataDir;
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CheckToneFile();
		toneInit();
	}

	private void toneInit() {
		String path = dir + "/tone";

		String SN = "1111111111111111";
		com.android.Tone.GenToneAPI.GenInit(SN, path);
	}

	public void onStartPlay(String SSID, String password, String BID, String Mode) {
		tA = new ToneAsync();
		tA.execute(SSID, password, BID, Mode);
	}

	public void onStopPlay() {
		if (aTrack != null) {
			if (aTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
				aTrack.stop();
			}
			aTrack.release();

		}
		if (tA != null) {
			tA.cancel(true);
		}

	}

	/**
	 * @param SSID
	 *            String 0~32
	 * @param password
	 *            String 0~64
	 * @param BID
	 *            String 4
	 * @param Mode
	 *            1 or 2 or 3 or 4
	 */
	public void setData(String SSID, String password, String BID, String Mode) {
		genTone(trans.transfer(SSID, password, BID, Mode));
	}

	public void genTone(byte[] inputdata) {

		if (inputdata == null) {
			return;
		}
		byte[] inputarray = inputdata;
		int packCount = (int) Math.ceil((float) inputarray.length / 26);

		short[] iarray;

		if (index < 8) {
			index++;

		} else {
			index = 0;
		}

		int samp_rate = 48000;
		int min = AudioTrack.getMinBufferSize(samp_rate, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT);

		aTrack = new AudioTrack(AudioManager.STREAM_MUSIC, samp_rate, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT, min, AudioTrack.MODE_STREAM);

		iarray = new short[83000 * packCount];
		aTrack.play();
		long length = com.android.Tone.GenToneAPI.GenTone(inputarray, iarray, index, packCount);

		aTrack.write(iarray, 0, (int) length);

	}

	private void CopyToneFileToPhone(int resFile, String fileName) {
		InputStream is = ctx.getResources().openRawResource(resFile);
		try {

			File toneFile = new File(dir + "/tone/" + fileName);
			FileOutputStream fos = new FileOutputStream(toneFile);
			byte[] buffer = new byte[1024];
			int count = 0;
			while ((count = is.read(buffer)) > 0) {
				fos.write(buffer, 0, count);
			}
			fos.close();
			is.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void CheckToneFile() {
		try {
			String dir = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).applicationInfo.dataDir;
			File mFilePath = new File(dir + "/tone");
			if (!mFilePath.exists()) {
				mFilePath.mkdirs();
				CopyToneFileToPhone(R.raw.startbit, "startbit.wav");
				CopyToneFileToPhone(R.raw.t01, "t01.wav");
				CopyToneFileToPhone(R.raw.t02, "t02.wav");
				CopyToneFileToPhone(R.raw.t03, "t03.wav");
				CopyToneFileToPhone(R.raw.t04, "t04.wav");
				CopyToneFileToPhone(R.raw.t05, "t05.wav");
				CopyToneFileToPhone(R.raw.t06, "t06.wav");
				CopyToneFileToPhone(R.raw.t07, "t07.wav");
				CopyToneFileToPhone(R.raw.t08, "t08.wav");
				CopyToneFileToPhone(R.raw.t09, "t09.wav");
				CopyToneFileToPhone(R.raw.t10, "t10.wav");
				CopyToneFileToPhone(R.raw.t11, "t11.wav");
				CopyToneFileToPhone(R.raw.t12, "t12.wav");
				CopyToneFileToPhone(R.raw.t13, "t13.wav");
				CopyToneFileToPhone(R.raw.t14, "t14.wav");
				CopyToneFileToPhone(R.raw.t15, "t15.wav");
				CopyToneFileToPhone(R.raw.t16, "t16.wav");
				CopyToneFileToPhone(R.raw.t17, "t17.wav");
				CopyToneFileToPhone(R.raw.t18, "t18.wav");
				CopyToneFileToPhone(R.raw.t19, "t19.wav");
				CopyToneFileToPhone(R.raw.t20, "t20.wav");
				CopyToneFileToPhone(R.raw.t21, "t21.wav");
				CopyToneFileToPhone(R.raw.t22, "t22.wav");
				CopyToneFileToPhone(R.raw.t23, "t23.wav");
				CopyToneFileToPhone(R.raw.t24, "t24.wav");
				CopyToneFileToPhone(R.raw.t25, "t25.wav");
				CopyToneFileToPhone(R.raw.t26, "t26.wav");
				CopyToneFileToPhone(R.raw.t27, "t27.wav");
				CopyToneFileToPhone(R.raw.t28, "t28.wav");
				CopyToneFileToPhone(R.raw.t29, "t29.wav");
				CopyToneFileToPhone(R.raw.t30, "t30.wav");
				CopyToneFileToPhone(R.raw.t31, "t31.wav");
				CopyToneFileToPhone(R.raw.t32, "t32.wav");
				CopyToneFileToPhone(R.raw.t33, "t33.wav");
				CopyToneFileToPhone(R.raw.t34, "t34.wav");
				CopyToneFileToPhone(R.raw.t35, "t35.wav");
				CopyToneFileToPhone(R.raw.t36, "t36.wav");

			} else {

			}
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	class ToneAsync extends AsyncTask<String, Void, Void> {

		@Override
		protected Void doInBackground(String... params) {
			// TODO Auto-generated method stub
			setData(params[0], params[1], params[2], params[3]);
			return null;

		}

		@Override
		protected void onCancelled() {
			// TODO Auto-generated method stub
			super.onCancelled();

			System.gc();

		}
	}
}
