package com.android.Tone;

public class GenToneAPI {
public native static void GenInit(String SN,String path);
public native static long GenTone(byte[] inputbuff,short[] outputbuff,int index,int size);
public native static int mTest(byte[] inputbuff);
	
	
	static { 
		try {
			System.loadLibrary("GenTone");
		}catch(UnsatisfiedLinkError ule) {
			System.out.println("loadLibrary(GenTone)," + ule.getMessage());
		}
	}

}
