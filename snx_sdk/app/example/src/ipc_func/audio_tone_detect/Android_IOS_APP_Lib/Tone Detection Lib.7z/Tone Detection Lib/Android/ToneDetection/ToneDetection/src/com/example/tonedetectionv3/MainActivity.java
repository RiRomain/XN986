package com.example.tonedetectionv3;

import com.android.Tone.GenTone;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	TextView tv;
	Button btn;
	String playString = "";
	GenTone gentone;
	EditText ssid_text;
	EditText pwd_text;
	EditText bid_text;
	int mode = 0;
	Spinner sp;
	private String[] wifi = { "OPEN", "WEP", "WPA", "WPA2" };
	ArrayAdapter<String> wifiList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		tv = (TextView) findViewById(R.id.textView1);
		btn = (Button) findViewById(R.id.gen_tone);
		ssid_text = (EditText) findViewById(R.id.ssid_test);
		pwd_text = (EditText) findViewById(R.id.pwd_test);
		bid_text = (EditText) findViewById(R.id.bid_test);
		sp = (Spinner) findViewById(R.id.wifi_mode);
		gentone = new GenTone(MainActivity.this);
		wifiList = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item, wifi);

		sp.setAdapter(wifiList);
		btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (ssid_text.getText().toString().equals("")) {
					Toast.makeText(MainActivity.this, "Please input SSID", Toast.LENGTH_SHORT).show();
					return;
				}
				if (pwd_text.getText().toString().equals("")) {
					Toast.makeText(MainActivity.this, "Please input Password", Toast.LENGTH_SHORT).show();
					return;
				}
				if (bid_text.getText().toString().equals("")) {
					Toast.makeText(MainActivity.this, "Please input Bid", Toast.LENGTH_SHORT).show();
					return;
				}
				gentone.onStartPlay(ssid_text.getText().toString(), pwd_text.getText().toString(), bid_text.getText().toString(), String.valueOf(mode));

			}

		});
		sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				switch (position) {
				case 0:
					mode = 1;
					break;
				case 1:
					mode = 2;
					break;
				case 2:
					mode = 3;
					break;
				case 3:
					mode = 4;
					break;
				default:
					break;
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub

				mode = 0;
			}
		});
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		gentone.onStopPlay();
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub

		super.onDestroy();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public static String randomString(int len) {
		String str = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < len; i++) {
			int idx = (int) (Math.random() * str.length());
			sb.append(str.charAt(idx));
		}
		return sb.toString();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
